const MOD='ecos-frontera',incidencias=[];
export const PRUEBAS_REALES=[
 {id:'creacion',titulo:'Crear y revisar un personaje',pasos:'En una ficha de prueba importa clase, especie y trasfondo con Plutonium. Completa los avances. La revisión debe detectar elecciones pendientes o repetidas. Aprueba desde el DM y cambia una elección: debe pedir revisión nueva.'},
 {id:'ecos',titulo:'Separar Ecos y Verbe',pasos:'Activa las reglas de Ecos desde la revisión del DM. Comprueba el indicador. Despierta el Verbe por separado y revisa linaje, fuerza, reserva y ramas. Apagar uno no debe modificar el otro.'},
 {id:'uso',titulo:'Aprender y usar una técnica',pasos:'Aprende una técnica de grado 1 en una copia con recursos conocidos. Marca un objetivo válido. Usa la técnica y comprueba un solo gasto, tirada y tarjeta de resolución.'},
 {id:'defensa',titulo:'Defensa antes del choque',pasos:'Con dos hojas despiertas prueba Sustitución frente a un ataque. Después prueba un ataque que siga siendo válido: el choque debe ofrecerse después de las defensas y respetar sus costes.'},
 {id:'area',titulo:'Área con varios objetivos',pasos:'Marca al menos dos defensores y una criatura sin Verbe. Intercepta contra uno: los demás objetivos deben conservar su resolución. Comprueba alcance, plantilla y salvaciones.'},
 {id:'reaccion',titulo:'Choque con reacción gastada',pasos:'Gasta la reacción ordinaria de un defensor. Provoca un choque válido: debe poder pagar su contratécnica sin recibir una acción ofensiva o daño adicional.'},
 {id:'azar',titulo:'Resultados naturales 1 y 20',pasos:'Desde tiradas nativas prueba ventaja y desventaja, varios ataques y una salvación. Solo cuenta el primer d20 válido del turno global. El GM principal aprueba. CA y velocidad deben vencer en su momento.'},
 {id:'ocultas',titulo:'Información y tiradas privadas',pasos:'Conecta un jugador y el DM. Prueba tiradas ocultas y búsquedas. El jugador no debe recibir diarios, páginas o reliquias privadas; las propuestas de d20 deben conservar destinatarios.'},
 {id:'descanso',titulo:'Descansos y deuda',pasos:'Anota Verbe, deuda, presupuesto breve y usos diarios. Completa un Corto y después el Largo correspondiente. Comprueba los límites compartidos y las excepciones descritas, como Sustitución refleja.'},
 {id:'npc',titulo:'Variantes de NPC y reversión',pasos:'Usa un NPC importado con Multiataque o magia. Revisa los avisos. Crea una copia privada y comprueba que el original no cambie. Actualiza una copia de prueba y deshaz su última adaptación.'},
 {id:'sintetico',titulo:'Tokens vinculados y no vinculados',pasos:'Repite un gasto, un efecto breve y su vencimiento en un token vinculado y en uno no vinculado. Los cambios deben afectar a la instancia correcta.'},
 {id:'correccion',titulo:'Corrección de un gasto simple',pasos:'Usa una técnica ordinaria de grado bajo sin efectos de recurso especiales. Desde el DM corrige su gasto antes de otro uso: debe restaurar solo Verbe. Un uso posterior o un poder complejo debe bloquear esa corrección automática.'},
 {id:'reconexion',titulo:'Recargar y reconectar',pasos:'Recarga jugador y DM después de un uso. Comprueba recursos, efectos, permisos y tarjetas. Revisa que el módulo no cobre de nuevo ni duplique una resolución.'},
 {id:'actualizacion',titulo:'Actualizar con respaldo',pasos:'Con Foundry cerrado, deja que el actualizador privado instale el Release. Reabre el mundo de prueba y comprueba versión y datos. Conserva el respaldo hasta terminar la revisión.'},
 {id:'sesion',titulo:'Primera escena sin manual',pasos:'Pide a alguien nuevo que cree una ficha de prueba, encuentre una técnica por intención y juegue una escena social y otra de combate. Anota dónde necesitó una explicación externa.'},
 {id:'plantilla35',titulo:'3.5 · Cono que no te alcanza',pasos:'En una escena medida en pies, usa Aliento de brasa con un objetivo delante. El cono debe medir 15 pies, colocarse desde ti y no dañarte. Repite en una escena en metros (4,5 m).'},
 {id:'ventaja35',titulo:'3.5 · Ventaja en cada ataque',pasos:'Ataca con un PJ y con un PNJ. Siempre debe abrirse la ventana Normal/Ventaja/Desventaja; con un objetivo derribado o un efecto que dé ventaja, la ventana debe avisarlo y preguntarte si la usas.'},
 {id:'estados35',titulo:'3.5 · Preguntar antes de un estado',pasos:'Con un PNJ, usa un ataque o técnica que derribe o aturda a un PJ. El DM debe ver «¿Aplicar…?» con lo que provoca y el jugador el aviso en el chat. Responde No: no debe aplicarse. Repite con Sí.'},
 {id:'moneda35',titulo:'3.5 · Pausa para la Moneda Antigua',pasos:'Con un PJ con Monedas Antiguas, falla un ataque y una salvación (sin sacar 1). Debe ofrecerse gastar una para repetir; al aceptar, la tirada nueva cuenta y la tarjeta lo anota.'},
 {id:'sustitucion35',titulo:'3.5 · Sustitución contra un PNJ fuera de combate',pasos:'Sin combate, haz que un PNJ muerda dos veces a un PJ con Sustitución. Las dos veces debe ofrecerse. Deja al PJ sin Verbe y Agotamiento 4: el chat debe explicar por qué no puede y cuánto costaría.'},
 {id:'descanso35',titulo:'3.5 · Descanso Corto solo para gastar',pasos:'Con un PJ herido y Dados de Golpe gastados, haz un Descanso Corto: no debe recuperar dados y debe abrirse la ventana para gastarlos. Prueba «Gastar hasta el tope».'},
 {id:'editor35',titulo:'3.5 · Editar y restaurar una técnica',pasos:'En Dirección → Editar técnicas, cambia los dados de una técnica que sepa un PJ. Su ficha debe mostrar el valor nuevo. Restaura el original y comprueba que vuelve. Borra Getsuga Tenshō del catálogo del mundo.'},
 {id:'devolver35',titulo:'3.5 · Devolver Verbe',pasos:'Usa una técnica y, desde su tarjeta, devuelve 2 de Verbe con un motivo. Debe sumarse sin pasar del máximo y aparecer en la tarjeta y en Dirección → Últimas devoluciones.'},
 {id:'etapas36',titulo:'3.6 · Etapas y naturaleza oculta',pasos:'Despierta una ficha de prueba en etapa Aprendiz con naturaleza secreta. No debe ver técnicas elementales ni poder aprender otra rama. Abre la siguiente etapa desde Herramientas del DM, pide el entrenamiento de naturaleza, da por terminados los días y haz la prueba.'},
 {id:'reserva36',titulo:'3.6 · Reserva por dados',pasos:'Despierta una ficha con «Tirar dados»: el chat debe mostrar una tirada por nivel y el máximo debe ser su suma más la característica. Súbela un nivel: debe tirar ese nivel. Otra ficha en «Promedio» debe quedar como la tabla.'},
 {id:'sangre36',titulo:'3.6 · Una sola sangre',pasos:'En una ficha con linaje, intenta abrirle una Mirada heredada distinta: debe negarse. Como trasplante sí. Con el linaje secreto, el bloque «Sangre de…» del Inicio debe explicarlo y «Activar técnicas familiares» debe abrirlas.'},
 {id:'oponentes36',titulo:'3.6 · Oponentes impredecibles',pasos:'En Diagnóstico, pulsa «Ocultar datos exactos de los enemigos». Con un usuario jugador, comprueba que no ve la barra ni la ficha completa de un PNJ y que el ataque no muestra su CA. Crea dos PNJ con «Verbe variable»: deben salir distintos.'},
 {id:'curacion36',titulo:'3.6 · Curación con reposo',pasos:'Con un PJ con Herida No Tratada, trata con un Maestro de Pulso que tenga Médico del Verbe: la tirada debe llevar ventaja y el bono. Supera la CD por 5: cuenta dos días. Lanza Restauración menor otro día: cuenta dos días y no borra un nivel de golpe.'},
 {id:'cuerpo37',titulo:'3.7 · Técnicas de Cuerpo y de cuerpo a cuerpo',pasos:'Con un PJ que sepa un golpe de Cuerpo de 1,5 m, marca a un enemigo al lado y úsalo: debe tirar el ataque y el daño (antes no tiraba nada). Usa un refuerzo de Cuerpo (acción adicional): debe salir la ventana «Qué pasó».'},
 {id:'choque37',titulo:'3.7 · Choque y defensas de cualquier rama',pasos:'Ataca con una técnica de Cuerpo a un PJ despierto que sepa una contratécnica de Velo: debe ofrecerse el choque y, sin ventaja elemental, decidir Control + grado. Con Palma que desvía, la ventana de defensa debe ofrecerla y dar +3 a la CA.'},
 {id:'cargadas37',titulo:'3.7 · Canalizar y liberar',pasos:'En combate, canaliza Lanza de tormenta: el token queda quieto y sin reacción. Pasa un turno y libérala: debe tirar con 1 dado más. Repite y hazle daño mientras canaliza: debe tirar Constitución y, si falla, perder la carga.'},
 {id:'clones37',titulo:'3.7 · Clones con ficha propia',pasos:'Con un PJ que sepa Clon de sombra, úsalo y elige 2 de Verbe: debe aparecer «Clon de…» junto a él con 1 PG y 2 de Verbe. Hazle daño: debe desaparecer y el DM ver la ventana de recuerdos. Crea otro y disípalo desde su panel: debe devolver su Verbe.'},
 {id:'musica39',titulo:'3.9 · Música de YouTube',pasos:'En Mesa Ecos → Control, pega un enlace de YouTube y pulsa Reproducir: un jugador debe oírlo y ver el recuadro abajo a la izquierda. Pausa y Seguir: los dos en el mismo punto. El jugador recarga: retoma donde iba. Añade dos a la cola: al terminar uno suena el siguiente. El volumen y «Silenciar» del jugador solo cambian lo suyo.'}
];
export function anotarIncidencia(codigo){incidencias.push({codigo:String(codigo).replace(/[^a-z0-9:._-]/gi,'').slice(0,90),fecha:new Date().toISOString()});if(incidencias.length>30)incidencias.shift();}
export function diagnosticoMesa(){
 const mods=['ecos-frontera','plutonium','midi-qol','item-piles','itempilesdnd5e'].map(id=>{const m=game.modules.get(id);return {id,instalado:!!m,activo:!!m?.active,version:m?.version??null};});
 const avisos=[],core=String(game.version??game.release?.version??'desconocida'),sistema=game.system??{};
 if(!core.startsWith('13.'))avisos.push('Esta revisión apunta a Foundry 13; comprueba la compatibilidad de tu versión.');
 if(sistema.id!=='dnd5e')avisos.push('La integración requiere el sistema dnd5e.');
 if(sistema.version!=='5.2.5')avisos.push('La base de integración comprobada en código es dnd5e 5.2.5; tu combinación necesita las pruebas reales.');
 if(game.modules.get('plutonium')?.active&&!game.modules.get('plutonium')?.api?.importer?.pOpen)avisos.push('Plutonium no expone el importador esperado. Usa su botón nativo y registra la versión.');
 const api=game.modules.get(MOD)?.api;
 if(!api?.verbe?.datos?.())avisos.push('El catálogo del Verbe no está disponible: revisa Capa V y espera a que termine la carga.');
 if(!game.users?.activeGM)avisos.push('No hay GM principal conectado para propuestas y operaciones que requieren DM.');
 return {formato:1,fecha:new Date().toISOString(),core,sistema:{id:sistema.id??null,version:sistema.version??null},modulos:mods,
  ...(game.user.isGM?{pruebas:PRUEBAS_REALES.map(p=>({id:p.id,estado:(()=>{const x=game.journal?.find(j=>j.getFlag?.(MOD,'pruebasMesa'))?.getFlag(MOD,'resultadoPruebas')?.[p.id]?.estado;return ['pendiente','correcto','fallo','no-aplica'].includes(x)?x:'pendiente';})()}))}:{}),
  capacidades:{importador:!!game.modules.get('plutonium')?.api?.importer?.pOpen,midi:!!game.modules.get('midi-qol')?.active,verbe:!!api?.verbe?.datos?.(),resolucion:!!api?.resolucion},avisos,incidencias:[...incidencias],
  privacidad:'Informe técnico sin nombres de actores, secretos, diarios, tokens, rutas locales ni credenciales. No prueba que una sesión real haya pasado.'};
}
export async function cuadernoPruebas(){
 if(!game.user.isGM)return null;let j=game.journal?.find(x=>x.getFlag(MOD,'pruebasMesa'));
 const ownership={default:0,...Object.fromEntries(Array.from(game.users).filter(u=>!u.isGM).map(u=>[u.id,0]))};
 if(!j)j=await JournalEntry.create({name:'Ecos · Pruebas reales de mesa (DM)',ownership,flags:{[MOD]:{pruebasMesa:true}},pages:[{name:'Recorrido de validación 3.4',type:'text',text:{format:1,content:'<h1>Antes de la primera sesión</h1><p>Haz estas pruebas en un mundo o fichas de prueba con respaldo. El módulo no las marca como superadas por ejecutar pruebas de código.</p>'+PRUEBAS_REALES.map(p=>`<h2>${p.titulo}</h2><p>${p.pasos}</p>`).join('')}}]});
 await j.update({ownership},{diff:false,recursive:false});return j;
}
export async function registrarPrueba(id,estado,nota=''){
 if(!game.user.isGM||!PRUEBAS_REALES.some(p=>p.id===id)||!['pendiente','correcto','fallo','no-aplica'].includes(estado))return false;
 const j=await cuadernoPruebas(),datos=j.getFlag(MOD,'resultadoPruebas')??{};
 await j.setFlag(MOD,'resultadoPruebas',{...datos,[id]:{estado,nota:String(nota).slice(0,1000),fecha:new Date().toISOString(),por:game.user.id}});return true;
}
export function exportarDiagnostico(){const data=diagnosticoMesa();saveDataToFile(JSON.stringify(data,null,2),'application/json','Ecos-Diagnostico.json');return data;}
